to run it u need to type these commands in terminal

gcc -c mylib/mylib.c -o mylib.o 
MinGW-make 
./main.exe

to use the bench mark change all main into main_time for time and main_space for space

my benchmarks are: 
time complexity = 0.001000 seconds
space complexity = 13-17% cpu , 1,7 mb memory

proof is in the photo folder